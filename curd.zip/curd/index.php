<?php include 'inc/header.php'; ?>
<?php include 'config.php'; ?>
<?php include 'database.php'; ?>

<?php
    
    $db = new Database();
    $query = "SELECT * FROM tbl_user";
    $read  = $db->select($query);



?>
<?php 
//create funtion

    if (isset($_GET['msg'])) {
    	echo "<span style='color:green'>".$_GET['msg']."</span>";
    }


?>



<table class="tbl_one" width="100%">
	<tr>
		<th width="10%">Id</th>
		<th width="25%">Name</th>
		<th width="25%">Email</th>
		<th width="25%">Skills</th>
		<th width="25%">Action</th>
	</tr>
<?php if($read){   ?>
	<?php
	$i=1;
	 while($row = $read->fetch_assoc()) { 
	?>
	<tr>
		<td><?php echo $i++; ?></td>
		<td><?php echo $row['name']; ?></td>
		<td><?php echo $row['email']; ?></td>
		<td><?php echo $row['skill']; ?></td>
		<td><a href="update.php?id=<?php echo urlencode($row['id']); ?> ">Edit</a> </td>
	</tr>
<?php  } ?>
<?php  } else{ ?>
<p>Data is not availbale</p>

<?php }?>
</table>

<a href="create.php">Create</a>



<?php include 'inc/footer.php'; ?>