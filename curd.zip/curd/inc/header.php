<!DOCTYPE html>
<html>
<head>
	<title>CURD</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<section class="headersection">
   <h2>PHP CURD</h2>
</section>
<section class="bodypart">
